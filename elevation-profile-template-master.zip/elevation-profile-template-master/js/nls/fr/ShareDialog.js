define({
  "widgets": {
    "ShareDialog": {
      "title": "Partager",
      "heading": "Partager cette carte",
      "url": "Lien de la carte",
      "embed": "Incorporer la carte",
      "extent": "Partager l'étendue de carte actuelle",
      "size": "Taille (largeur/hauteur):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "Courrier électronique"
    }
  }
});