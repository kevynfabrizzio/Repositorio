define({
  "widgets": {
    "ShareDialog": {
      "title": "Sdílet",
      "heading": "Sdílejte tuto mapu",
      "url": "Odkaz na mapu",
      "embed": "Vložit mapu",
      "extent": "Sdílet současný rozsah mapy",
      "size": "Velikost (šířka/výška):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "E-mail"
    }
  }
});