define({
  "widgets": {
    "ShareDialog": {
      "title": "Partajare",
      "heading": "Partajare această hartă",
      "url": "Link către hartă",
      "embed": "Încorporare hartă",
      "extent": "Partajare extindere curentă a hărţii",
      "size": "Dimensiune (lăţime/înălţime):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "E-mail"
    }
  }
});