define({
  "widgets": {
    "ShareDialog": {
      "title": "שתף",
      "heading": "שתף מפה זו",
      "url": "קישור למפה",
      "embed": "הטמע את המפה",
      "extent": "שתף את תיחום המפה הנוכחי",
      "size": "גודל (רוחב/גובה):",
      "facebookTooltip": "פייסבוק",
      "twitterTooltip": "טוויטר",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "דוא\"ל"
    }
  }
});