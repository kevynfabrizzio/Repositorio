define({
  "widgets": {
    "ShareDialog": {
      "title": "共享",
      "heading": "共享此地图",
      "url": "地图链接",
      "embed": "嵌入地图",
      "extent": "共享当前地图范围",
      "size": "大小(宽度/高度):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google +",
      "emailTooltip": "电子邮件"
    }
  }
});