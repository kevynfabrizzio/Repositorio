define({
  "widgets": {
    "ShareDialog": {
      "title": "Del",
      "heading": "Del dette kort",
      "url": "Kort-link",
      "embed": "Integrér kort",
      "extent": "Del aktuelt kortområde",
      "size": "Størrelse (bredde/højde):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "E-mail"
    }
  }
});