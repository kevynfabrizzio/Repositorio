define({
  "widgets": {
    "ShareDialog": {
      "title": "Condividi",
      "heading": "Condividi la mappa",
      "url": "Collegamento a mappa",
      "embed": "Incorpora mappa",
      "extent": "Condividi estensione mappa corrente",
      "size": "Dimensioni (larghezza/altezza):",
      "facebookTooltip": "Facebook",
      "twitterTooltip": "Twitter",
      "gplusTooltip": "Google Plus",
      "emailTooltip": "E-mail"
    }
  }
});